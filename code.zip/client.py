from Models.Player import Player

def main():
    client = Player()

main()